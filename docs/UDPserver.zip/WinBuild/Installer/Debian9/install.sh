#!/bin/bash

sudo dpkg -i ./apt.deb
sudo cp source-debian.list /etc/apt/sources.list.d/
sudo cp -r ./trusted.gpg.d/* /etc/apt/trusted.gpg.d/
sudo apt update --allow-unauthenticated

sudo apt install -y wget --allow-unauthenticated

wget -O - https://packages.microsoft.com/keys/microsoft.asc | gpg --dearmor > microsoft.asc.gpg
sudo mv microsoft.asc.gpg /etc/apt/trusted.gpg.d/
wget https://packages.microsoft.com/config/debian/9/prod.list
sudo mv prod.list /etc/apt/sources.list.d/microsoft-prod.list
sudo chown root:root /etc/apt/trusted.gpg.d/microsoft.asc.gpg
sudo chown root:root /etc/apt/sources.list.d/microsoft-prod.list

sudo apt-get update --allow-unauthenticated; \
  sudo apt-get install -y apt-transport-https --allow-unauthenticated && \
  sudo apt-get update --allow-unauthenticated && \
  sudo apt-get install -y dotnet-sdk-6.0


sudo apt install -y libgdiplus blueman bluez --allow-unauthenticated
sudo gpasswd --add "${USER}" dialout

chmod +x ./ZLabs
