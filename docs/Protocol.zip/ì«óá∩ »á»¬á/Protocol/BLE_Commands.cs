﻿using HardwareLib.ModbusCRC16;
using HardwareLib.Update;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static HardwareLib.EnumClass;

namespace HardwareLib.Classes
{
    public class BLE_Commands
    {
        const byte unsupportMsg = 0xFF;
        const byte startByte = 0xAA;

        const byte proto_msgType_getInfo_BT = 0x01;
        const byte get_HW_Config_BT = 0x32;
        const byte data_exchange_BT = 0x11;
        const byte set_UserData = 0x40;
        
        #region CRC Modbus
        private static byte[] CalculateCrc16Modbus(byte[] bytes)
        {
            byte[] myArray = new byte[bytes.Length - 2];
            for (int i = 0; i < myArray.Length; i++)
            {
                myArray[i] = bytes[i];
            }
            CrcStdParams.StandartParameters.TryGetValue(CrcAlgorithms.Crc16Modbus, out Parameters crc_p);
            Crc crc = new Crc(crc_p);
            crc.Initialize();
            var crc_bytes = crc.ComputeHash(myArray);
            return crc_bytes;
        }

        private bool CheckAnswer(byte[] answerArray)
        {
            bool correct;
            var crc = CalculateCrc16Modbus(answerArray);
            correct = crc[0] == answerArray[answerArray.Length - 2] && crc[1] == answerArray[answerArray.Length - 1];
            return correct;
        }
        #endregion

        /// <summary>
        /// BLE
        /// Запрос тип лаборатории, режима работы (загрузчик, основная), состояние конфигов 
        /// </summary>
        /// <returns></returns>
        public byte[] Proto_msgType_getInfo_BT()
        {
            byte[] writeMessage = new byte[6];
            writeMessage[0] = startByte;

            writeMessage[1] = BitConverter.GetBytes(writeMessage.Length)[0];
            writeMessage[2] = BitConverter.GetBytes(writeMessage.Length)[1];

            writeMessage[3] = proto_msgType_getInfo_BT;

            var crc = CalculateCrc16Modbus(writeMessage);
            writeMessage[4] = crc[0];
            writeMessage[5] = crc[1];

            return writeMessage;
        }

        /// <summary>
        /// BLE Ответ
        /// узнать тип лаборатории
        /// </summary>
        /// <param name="massive"></param>
        /// <returns></returns>
        public LabType Answer_proto_msgType_getInfo_BT(byte[] massive)
        {
            return (LabType)massive[10];
        }

        /// <summary>
        /// BLE Запрос чтение заводских настроек
        /// </summary>
        /// <param name="DataOffset"></param>
        /// <param name="DataSize"></param>
        /// <returns></returns>
        public byte[] Get_HW_Config_BT(UInt16 DataOffset, UInt16 DataSize)
        {
            //TODO: в DigLab_v2_MainProg_v3.003.zbin неверная длина ответа, не 10+DataSize, а 6+DataSize
            //поэтому запрашиваем байт больше, чем надо
            byte[] writeMessage = new byte[10];
            writeMessage[0] = startByte;
            writeMessage[1] = BitConverter.GetBytes(writeMessage.Length)[0];
            writeMessage[2] = BitConverter.GetBytes(writeMessage.Length)[1];
            writeMessage[3] = get_HW_Config_BT;

            //UInt16 DataOffset = 32;
            writeMessage[4] = BitConverter.GetBytes(DataOffset)[0];
            writeMessage[5] = BitConverter.GetBytes(DataOffset)[1];

            //UInt16 DataSize = 76;
            writeMessage[6] = BitConverter.GetBytes(DataSize)[0];
            writeMessage[7] = BitConverter.GetBytes(DataSize)[1];

            var crc = CalculateCrc16Modbus(writeMessage);
            writeMessage[8] = crc[0];
            writeMessage[9] = crc[1];

            return writeMessage;
        }

        /// <summary>
        /// BLE ответ
        /// на чтение заводских настроек
        /// </summary>
        /// <param name="massive"></param>
        /// <returns></returns>
        public FactoryCoeffs Answer_get_HW_Config_BT(byte[] massive)
        {
            FactoryCoeffs factoryCoeffs = new FactoryCoeffs();
            factoryCoeffs.k_Channel0 = BitConverter.ToSingle(massive, 8);
            factoryCoeffs.delta_Channel0 = BitConverter.ToSingle(massive, 12);
            factoryCoeffs.k_Channel1 = BitConverter.ToSingle(massive, 16);
            factoryCoeffs.delta_Channel1 = BitConverter.ToSingle(massive, 20);
            factoryCoeffs.k1_Channel2 = BitConverter.ToSingle(massive, 24);
            factoryCoeffs.delta1_Channel2 = BitConverter.ToSingle(massive, 28);
            factoryCoeffs.k2_Channel2 = BitConverter.ToSingle(massive, 32);
            factoryCoeffs.delta2_Channel2 = BitConverter.ToSingle(massive, 36);
            factoryCoeffs.pointT_Channel2 = BitConverter.ToSingle(massive, 40);
            factoryCoeffs.k1_Channel3 = BitConverter.ToSingle(massive, 44);
            factoryCoeffs.delta1_Channel3 = BitConverter.ToSingle(massive, 48);

            factoryCoeffs.delta_LightSensor = BitConverter.ToSingle(massive, 52);
            factoryCoeffs.delta_HumiditySensor = BitConverter.ToSingle(massive, 56);
            factoryCoeffs.delta_ToutSensor = BitConverter.ToSingle(massive, 60);
            factoryCoeffs.delta_AbsolutePressureSensor = BitConverter.ToSingle(massive, 64);

            factoryCoeffs.k2_Channel3 = BitConverter.ToSingle(massive, 68);
            factoryCoeffs.delta2_Channel3 = BitConverter.ToSingle(massive, 72);
            factoryCoeffs.k3_Channel3 = BitConverter.ToSingle(massive, 76);
            factoryCoeffs.delta3_Channel3 = BitConverter.ToSingle(massive, 80);

            return factoryCoeffs;
        }
        
        /// <summary>
        /// BLE запрос чтения данных
        /// </summary>
        /// <returns></returns>
        public byte[] DataExchange_BT_Read()
        {
            byte[] writeMessage = new byte[8];
            writeMessage[0] = startByte;
            writeMessage[1] = BitConverter.GetBytes(writeMessage.Length)[0];
            writeMessage[2] = BitConverter.GetBytes(writeMessage.Length)[1];
            writeMessage[3] = data_exchange_BT;

            writeMessage[4] = 0;
            writeMessage[5] = 49;  //TODO: полезных данных 45, косяк аналогичный как в Get_HW_Config_BT

            var crc = CalculateCrc16Modbus(writeMessage);
            writeMessage[6] = crc[0];
            writeMessage[7] = crc[1];

            return writeMessage;
        }

        private const float _2g_coeff = 0.064F * 0.001F;
        private const float _4g_coeff = 0.128F * 0.001F;
        private const float _8g_coeff = 0.256F * 0.001F;
        private const float _16g_coeff = 0.512F * 0.001F;
        private bool[] ByteToBits(byte bt)
        {
            bool[] bits = new bool[8];
            for (int i = 0; i < 8; i++)
            {
                bits[i] = (bt & (1 << i)) != 0;
            }
            return bits;
        }
        public Data[] Answer_Data_exchange_BT(byte[] massive, FactoryCoeffs factoryCoeffs, UserCoeffs userSavedCoeffs, UserCoeffs userNewCoeffs, ConductScale conductScale)
        {
            Data[] fullData = new Data[2];
            #region Сырые данные
            DataBoard dataBoard = new DataBoard();

            var state = ByteToBits(massive[6]);
            dataBoard.Press_ok = state[3];
            dataBoard.Hum_ok = state[2];
            dataBoard.Light_ok = state[1];
            dataBoard.Accel_ok = state[0];

            dataBoard.ConductScale = (ConductScale)massive[7];

            dataBoard.TempADC = BitConverter.ToInt16(massive, 14) * 0.01F;

            dataBoard.Channel0 = BitConverter.ToSingle(massive, 18);
            dataBoard.Channel1 = BitConverter.ToSingle(massive, 22);
            dataBoard.Channel2 = BitConverter.ToSingle(massive, 26);
            dataBoard.Channel3 = BitConverter.ToSingle(massive, 30);

            dataBoard.AccelX = BitConverter.ToInt16(massive, 34);
            dataBoard.AccelY = BitConverter.ToInt16(massive, 36);
            dataBoard.AccelZ = BitConverter.ToInt16(massive, 38);
            dataBoard.AccelScale = (AccelScale)massive[40];

            dataBoard.Light = BitConverter.ToSingle(massive, 42);
            dataBoard.Humidity = BitConverter.ToUInt16(massive, 46) * 0.01F;

            dataBoard.Pressure = BitConverter.ToSingle(massive, 50);
            #endregion

            #region C учетом коэффициентов

            Data data = new Data();
            Data data_withFactoryCoef = new Data();

            #region Accelerometr пересчет в зависимости от диапазона (физика)
            if (dataBoard.Accel_ok)
            {
                switch (dataBoard.AccelScale)
                {
                    case AccelScale.g2:
                        data.AccelerometerXSensor = dataBoard.AccelX * _2g_coeff;
                        data.AccelerometerYSensor = dataBoard.AccelY * _2g_coeff;
                        data.AccelerometerZSensor = dataBoard.AccelZ * _2g_coeff;
                        break;

                    case AccelScale.g4:
                        data.AccelerometerXSensor = dataBoard.AccelX * _4g_coeff;
                        data.AccelerometerYSensor = dataBoard.AccelY * _4g_coeff;
                        data.AccelerometerZSensor = dataBoard.AccelZ * _4g_coeff;
                        break;

                    case AccelScale.g8:
                        data.AccelerometerXSensor = dataBoard.AccelX * _8g_coeff;
                        data.AccelerometerYSensor = dataBoard.AccelY * _8g_coeff;
                        data.AccelerometerZSensor = dataBoard.AccelZ * _8g_coeff;
                        break;

                    case AccelScale.g16:
                        data.AccelerometerXSensor = dataBoard.AccelX * _16g_coeff;
                        data.AccelerometerYSensor = dataBoard.AccelY * _16g_coeff;
                        data.AccelerometerZSensor = dataBoard.AccelZ * _16g_coeff;
                        break;
                }
            }
            #endregion

            #region датчик давления (физика)
            data_withFactoryCoef.AbsolutePressureSensor = dataBoard.Pressure * 0.1F + factoryCoeffs.delta_AbsolutePressureSensor; //перевод в кПа
            data.AbsolutePressureSensor = data_withFactoryCoef.AbsolutePressureSensor + userSavedCoeffs.delta_AbsolutePressureSensor;
            #endregion

            #region датчик температуры - 2 канал АЦП (физика, химияб биология)
            if (dataBoard.Channel2 < factoryCoeffs.pointT_Channel2)
            {
                data_withFactoryCoef.TempSensor = dataBoard.Channel2 * factoryCoeffs.k1_Channel2 + factoryCoeffs.delta1_Channel2;
            }
            else
            {
                data_withFactoryCoef.TempSensor = dataBoard.Channel2 * factoryCoeffs.k2_Channel2 + factoryCoeffs.delta2_Channel2;
            }
            switch (userSavedCoeffs.step_TempSensor)
            {
                case 1:
                    data.TempSensor = data_withFactoryCoef.TempSensor + userSavedCoeffs.delta_TempSensor;
                    break;
                case 2:
                    data.TempSensor = data_withFactoryCoef.TempSensor * userSavedCoeffs.k_TempSensor + userSavedCoeffs.delta_TempSensor;
                    break;
            }
            #endregion

            #region тесламетр - канал 3 (физика)
            data_withFactoryCoef.TeslametrSensor = dataBoard.Channel3 * factoryCoeffs.k1_Channel3 + factoryCoeffs.delta1_Channel3;
            switch (userSavedCoeffs.step_TeslametrSensor)
            {
                case 1:
                    data.TeslametrSensor = data_withFactoryCoef.TeslametrSensor + userSavedCoeffs.delta_TeslametrSensor;
                    break;
                case 2:
                    data.TeslametrSensor = data_withFactoryCoef.TeslametrSensor * userSavedCoeffs.k_TeslametrSensor + userSavedCoeffs.delta_TeslametrSensor;
                    break;
            }
            #endregion

            #region вольтметр - канал 0 (физика)
            data_withFactoryCoef.VoltmeterSensor = dataBoard.Channel0 * factoryCoeffs.k_Channel0 + factoryCoeffs.delta_Channel0;
            switch (userSavedCoeffs.step_VoltmeterSensor)
            {
                case 1:
                    data.VoltmeterSensor = data_withFactoryCoef.VoltmeterSensor + userSavedCoeffs.delta_VoltmeterSensor;
                    break;
                case 2:
                    data.VoltmeterSensor = data_withFactoryCoef.VoltmeterSensor * userSavedCoeffs.k_VoltmeterSensor + userSavedCoeffs.delta_VoltmeterSensor;
                    break;
            }
            #endregion

            #region амперметр - канал 1 (физика)
            data_withFactoryCoef.AmpermetrSensor = dataBoard.Channel1 * factoryCoeffs.k_Channel1 + factoryCoeffs.delta_Channel1;
            switch (userSavedCoeffs.step_AmpermetrSensor)
            {
                case 1:
                    data.AmpermetrSensor = data_withFactoryCoef.AmpermetrSensor + userSavedCoeffs.delta_AmpermetrSensor;
                    break;
                case 2:
                    data.AmpermetrSensor = data_withFactoryCoef.AmpermetrSensor * userSavedCoeffs.k_AmpermetrSensor + userSavedCoeffs.delta_AmpermetrSensor;
                    break;
            }
            #endregion

            #region датчик рН - 0 канал (химия)
            data_withFactoryCoef.PhSensor = dataBoard.Channel0 * 1000 * factoryCoeffs.k_Channel0 + factoryCoeffs.delta_Channel0;
            data.PhSensor = data_withFactoryCoef.PhSensor * userSavedCoeffs.k_pHSensor + userSavedCoeffs.delta_pHSensor;
            #endregion

            #region датчик электропроводимсоти - 3 канал (химия)
            data_withFactoryCoef.ElectricalConductivitySensor = dataBoard.Channel3 * factoryCoeffs.k1_Channel3 + factoryCoeffs.delta1_Channel3;
            switch (conductScale)
            {
                case ConductScale.k0:
                    break;
                case ConductScale.k1:
                    data.ElectricalConductivitySensor = data_withFactoryCoef.ElectricalConductivitySensor * userSavedCoeffs.k1_ConductivitySensor + userSavedCoeffs.delta1_ConductivitySensor;
                    break;
                case ConductScale.k10:
                    data.ElectricalConductivitySensor = data_withFactoryCoef.ElectricalConductivitySensor * userSavedCoeffs.k2_ConductivitySensor + userSavedCoeffs.delta2_ConductivitySensor;
                    break;
                case ConductScale.k100:
                    data.ElectricalConductivitySensor = data_withFactoryCoef.ElectricalConductivitySensor * userSavedCoeffs.k3_ConductivitySensor + userSavedCoeffs.delta3_ConductivitySensor;
                    break;
            }
            #endregion

            #region датчик влажности (биология)
            data_withFactoryCoef.HumiditySensor = dataBoard.Humidity + factoryCoeffs.delta_HumiditySensor;
            data.HumiditySensor = data_withFactoryCoef.HumiditySensor + userSavedCoeffs.delta_HumiditySensor;
            #endregion

            #region датчик освещенности (биология)
            data_withFactoryCoef.LightSensor = dataBoard.Light + factoryCoeffs.delta_LightSensor;
            data.LightSensor = data_withFactoryCoef.LightSensor + userSavedCoeffs.delta_LightSensor;
            #endregion


            #region датчик температуры окруж.среды (биология)
            data_withFactoryCoef.TempOutsideSensor = dataBoard.TempADC + factoryCoeffs.delta_ToutSensor;
            data.TempOutsideSensor = data_withFactoryCoef.TempOutsideSensor + userSavedCoeffs.delta_TempOutsideSensor;
            #endregion
            #endregion

            #region Данные для отображения в окне калибровки

            #region датчик температуры (физика, химия, биология)
            switch (userNewCoeffs.step_TempSensor)
            {
                case 1:
                    data.TempSensor_Calibr = data_withFactoryCoef.TempSensor + userNewCoeffs.delta_TempSensor;
                    break;
                case 2:
                    data.TempSensor_Calibr = data_withFactoryCoef.TempSensor * userNewCoeffs.k_TempSensor + userNewCoeffs.delta_TempSensor;
                    break;
            }
            #endregion

            #region Тесламетр (физика)
            switch (userNewCoeffs.step_TeslametrSensor)
            {
                case 1:
                    data.TeslametrSensor_Calibr = data_withFactoryCoef.TeslametrSensor + userNewCoeffs.delta_TeslametrSensor;
                    break;
                case 2:
                    data.TeslametrSensor_Calibr = data_withFactoryCoef.TeslametrSensor * userNewCoeffs.k_TeslametrSensor + userNewCoeffs.delta_TeslametrSensor;
                    break;
            }
            #endregion

            #region Вольтметр (физика)
            switch (userNewCoeffs.step_VoltmeterSensor)
            {
                case 1:
                    data.VoltmeterSensor_Calibr = data_withFactoryCoef.VoltmeterSensor + userNewCoeffs.delta_VoltmeterSensor;
                    break;
                case 2:
                    data.VoltmeterSensor_Calibr = data_withFactoryCoef.VoltmeterSensor * userNewCoeffs.k_VoltmeterSensor + userNewCoeffs.delta_VoltmeterSensor;
                    break;
            }
            #endregion

            #region Амперметр (физика)
            switch (userNewCoeffs.step_AmpermetrSensor)
            {
                case 1:
                    data.AmpermetrSensor_Calibr = data_withFactoryCoef.AmpermetrSensor + userNewCoeffs.delta_AmpermetrSensor;
                    break;
                case 2:
                    data.AmpermetrSensor_Calibr = data_withFactoryCoef.AmpermetrSensor * userNewCoeffs.k_AmpermetrSensor + userNewCoeffs.delta_AmpermetrSensor;
                    break;
            }
            #endregion

            #region Датчик давления (физика)
            data.AbsolutePressureSensor_Calibr = data_withFactoryCoef.AbsolutePressureSensor + userNewCoeffs.delta_AbsolutePressureSensor;
            #endregion

            #region pH (химия)
            data.PhSensor_Calibr = data.PhSensor * userNewCoeffs.k_pHSensor + userNewCoeffs.delta_pHSensor;
            #endregion

            #region датчик электропроводимсоти (химия)
            switch (conductScale)
            {
                case ConductScale.k0:
                    break;
                case ConductScale.k1:
                    data.ElectricalConductivitySensor_Calibr = data_withFactoryCoef.ElectricalConductivitySensor * userNewCoeffs.k1_ConductivitySensor + userNewCoeffs.delta1_ConductivitySensor;
                    break;
                case ConductScale.k10:
                    data.ElectricalConductivitySensor_Calibr = data_withFactoryCoef.ElectricalConductivitySensor * userNewCoeffs.k2_ConductivitySensor + userNewCoeffs.delta2_ConductivitySensor;
                    break;
                case ConductScale.k100:
                    data.ElectricalConductivitySensor_Calibr = data_withFactoryCoef.ElectricalConductivitySensor * userNewCoeffs.k3_ConductivitySensor + userNewCoeffs.delta3_ConductivitySensor;
                    break;
            }
            #endregion

            #region датчик влажности (биология)
            data.HumiditySensor_Calibr = data_withFactoryCoef.HumiditySensor + userNewCoeffs.delta_HumiditySensor;
            #endregion

            #region датчик освещенности (биология)
            data.LightSensor_Calibr = data_withFactoryCoef.LightSensor + userNewCoeffs.delta_LightSensor;
            #endregion

            #region датчик температуры наружн (биология)
            data.TempOutsideSensor_Calibr = data_withFactoryCoef.TempOutsideSensor + userNewCoeffs.delta_TempOutsideSensor;
            #endregion

            #endregion

            fullData[0] = data_withFactoryCoef;
            fullData[1] = data;

            return fullData;
        }

        /// <summary>
        /// BLE запрос на установку шкалы
        /// </summary>
        /// <param name="accelScale"></param>
        /// <param name="conductScale"></param>
        /// <returns></returns>
        public byte[] DataExchange_BT_WriteScales(byte accelScale, byte conductScale)
        {
            byte[] writeMessage = new byte[10];
            writeMessage[0] = startByte;
            writeMessage[1] = BitConverter.GetBytes(writeMessage.Length)[0];
            writeMessage[2] = BitConverter.GetBytes(writeMessage.Length)[1];
            writeMessage[3] = data_exchange_BT;
           
            writeMessage[4] = 0; //адрес блок данных 
            writeMessage[5] = 1; //размер блок данных

            writeMessage[6] = accelScale;
            writeMessage[7] = conductScale;

            var crc = CalculateCrc16Modbus(writeMessage);
            writeMessage[8] = crc[0];
            writeMessage[9] = crc[1];

            return writeMessage;
        }

        /// <summary>
        /// запись пользовательских коэффициентов "кусочками"
        /// </summary>
        /// <param name="offset"></param>
        /// <param name="k"></param>
        /// <param name="delta"></param>
        /// <param name="step"></param>
        /// <returns></returns>
        public byte[] Proto_msgType_set_UserData(byte offset, float k, float delta, byte step)
        {
            byte[] writeMessage = new byte[21];
            writeMessage[0] = startByte;
            writeMessage[1] = BitConverter.GetBytes(writeMessage.Length)[0];
            writeMessage[2] = BitConverter.GetBytes(writeMessage.Length)[1];
            writeMessage[3] = set_UserData;
            writeMessage[4] = offset;
            writeMessage[5] = 12; //user calibr data len
            writeMessage[6] = 1;

            var kBytes = BitConverter.GetBytes(k);
            writeMessage[7] = kBytes[0];
            writeMessage[8] = kBytes[1];
            writeMessage[9] = kBytes[2];
            writeMessage[10] = kBytes[3];

            var deltaBytes = BitConverter.GetBytes(delta);
            writeMessage[11] = deltaBytes[0];
            writeMessage[12] = deltaBytes[1];
            writeMessage[13] = deltaBytes[2];
            writeMessage[14] = deltaBytes[3];

            var stepBytes = BitConverter.GetBytes((float)step);
            writeMessage[15] = stepBytes[0];
            writeMessage[16] = stepBytes[1];
            writeMessage[17] = stepBytes[2];
            writeMessage[18] = stepBytes[3];

            var crcChem = CalculateCrc16Modbus(writeMessage);
            writeMessage[19] = crcChem[0];
            writeMessage[20] = crcChem[1];

            return writeMessage;
        }

        public byte[] Proto_msgType_set_UserData(byte offset, float delta)
        {
            byte[] writeMessage = new byte[13];
            writeMessage[0] = startByte;
            writeMessage[1] = BitConverter.GetBytes(writeMessage.Length)[0];
            writeMessage[2] = BitConverter.GetBytes(writeMessage.Length)[1];
            writeMessage[3] = set_UserData;
            writeMessage[4] = offset;
            writeMessage[5] = 4; //user calibr data len
            writeMessage[6] = 1;

            var deltaBytes = BitConverter.GetBytes(delta);
            writeMessage[7] = deltaBytes[0];
            writeMessage[8] = deltaBytes[1];
            writeMessage[9] = deltaBytes[2];
            writeMessage[10] = deltaBytes[3];

            var crcChem = CalculateCrc16Modbus(writeMessage);
            writeMessage[11] = crcChem[0];
            writeMessage[12] = crcChem[1];

            return writeMessage;
        }

        public byte[] Proto_msgType_set_UserData(byte offset, float k, float delta)
        {
            byte[] writeMessage = new byte[17];
            writeMessage[0] = startByte;
            writeMessage[1] = BitConverter.GetBytes(writeMessage.Length)[0];
            writeMessage[2] = BitConverter.GetBytes(writeMessage.Length)[1];
            writeMessage[3] = set_UserData;
            writeMessage[4] = offset;
            writeMessage[5] = 8; //user calibr data len
            writeMessage[6] = 1;

            var kBytes = BitConverter.GetBytes(k);
            writeMessage[7] = kBytes[0];
            writeMessage[8] = kBytes[1];
            writeMessage[9] = kBytes[2];
            writeMessage[10] = kBytes[3];

            var deltaBytes = BitConverter.GetBytes(delta);
            writeMessage[11] = deltaBytes[0];
            writeMessage[12] = deltaBytes[1];
            writeMessage[13] = deltaBytes[2];
            writeMessage[14] = deltaBytes[3];

            var crcChem = CalculateCrc16Modbus(writeMessage);
            writeMessage[15] = crcChem[0];
            writeMessage[16] = crcChem[1];

            return writeMessage;
        }
    }
}
