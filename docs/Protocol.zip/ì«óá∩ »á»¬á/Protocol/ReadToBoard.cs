﻿using HardwareLib.Classes;
using HardwareLib.Update;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static HardwareLib.EnumClass;

namespace HardwareLib
{
    public class ReadToBoard
    {
        private const float _2g_coeff = 0.064F * 0.001F;
        private const float _4g_coeff = 0.128F * 0.001F;
        private const float _8g_coeff = 0.256F * 0.001F;
        private const float _16g_coeff = 0.512F * 0.001F;

        public float Get_2g_coeff() { return _2g_coeff; }
        public float Get_4g_coeff() { return _4g_coeff; }
        public float Get_8g_coeff() { return _8g_coeff; }
        public float Get_16g_coeff() { return _16g_coeff; }


        private bool[] ByteToBits(byte bt)
        {
            bool[] bits = new bool[8];
            for (int i = 0; i < 8; i++)
            {
                bits[i] = (bt & (1 << i)) != 0;
            }
            return bits;
        }

        /// <summary>
        /// узнать тип лаборатории
        /// </summary>
        /// <param name="massive"></param>
        /// <returns></returns>
        public LabType Answer_proto_msgType_getInfo(byte[] massive)
        {
            return (LabType)massive[10];
        }

        /// <summary>
        /// узнать заводские коэффициенты
        /// </summary>
        /// <param name="massive"></param>
        /// <returns></returns>
        public FactoryCoeffs Answer_get_HW_Config(byte[] massive)
        {
            FactoryCoeffs factoryCoeffs = new FactoryCoeffs();

            factoryCoeffs.k_Channel0 = BitConverter.ToSingle(massive, 36);
            factoryCoeffs.delta_Channel0 = BitConverter.ToSingle(massive, 40);
            factoryCoeffs.k_Channel1 = BitConverter.ToSingle(massive, 44);
            factoryCoeffs.delta_Channel1 = BitConverter.ToSingle(massive, 48);
            factoryCoeffs.k1_Channel2 = BitConverter.ToSingle(massive, 52);
            factoryCoeffs.delta1_Channel2 = BitConverter.ToSingle(massive, 56);
            factoryCoeffs.k2_Channel2 = BitConverter.ToSingle(massive, 60);
            factoryCoeffs.delta2_Channel2 = BitConverter.ToSingle(massive, 64);
            factoryCoeffs.pointT_Channel2 = BitConverter.ToSingle(massive, 68);
            factoryCoeffs.k1_Channel3 = BitConverter.ToSingle(massive, 72);
            factoryCoeffs.delta1_Channel3 = BitConverter.ToSingle(massive, 76);

            factoryCoeffs.delta_LightSensor = BitConverter.ToSingle(massive, 80);
            factoryCoeffs.delta_HumiditySensor = BitConverter.ToSingle(massive, 84);
            factoryCoeffs.delta_ToutSensor = BitConverter.ToSingle(massive, 88);
            factoryCoeffs.delta_AbsolutePressureSensor = BitConverter.ToSingle(massive, 92);

            factoryCoeffs.k2_Channel3 = BitConverter.ToSingle(massive, 96);
            factoryCoeffs.delta2_Channel3 = BitConverter.ToSingle(massive, 100);
            factoryCoeffs.k3_Channel3 = BitConverter.ToSingle(massive, 104);
            factoryCoeffs.delta3_Channel3 = BitConverter.ToSingle(massive, 108);

            return factoryCoeffs;
        }

        /// <summary>
        /// узнать пользовательские 
        /// </summary>
        /// <returns></returns>
        public UserCoeffs Answer_get_UserData(LabType labType, byte[] massive)
        {
            UserCoeffs userCoeffs = new UserCoeffs();
            switch (labType)
            {
                #region Phys
                case LabType.phys:
                   
                    userCoeffs.k_TempSensor = BitConverter.ToSingle(massive, 6);
                    userCoeffs.delta_TempSensor = BitConverter.ToSingle(massive, 10);
                    userCoeffs.step_TempSensor = (byte)Math.Truncate(BitConverter.ToSingle(massive, 14));

                    userCoeffs.k_TeslametrSensor = BitConverter.ToSingle(massive, 18);
                    userCoeffs.delta_TeslametrSensor = BitConverter.ToSingle(massive, 22);
                    userCoeffs.step_TeslametrSensor = (byte)Math.Truncate(BitConverter.ToSingle(massive, 26));

                    userCoeffs.k_VoltmeterSensor = BitConverter.ToSingle(massive, 30);
                    userCoeffs.delta_VoltmeterSensor = BitConverter.ToSingle(massive, 34);
                    userCoeffs.step_VoltmeterSensor = (byte)Math.Truncate(BitConverter.ToSingle(massive, 38));

                    userCoeffs.k_AmpermetrSensor = BitConverter.ToSingle(massive, 42);
                    userCoeffs.delta_AmpermetrSensor = BitConverter.ToSingle(massive, 46);
                    userCoeffs.step_AmpermetrSensor = (byte)Math.Truncate(BitConverter.ToSingle(massive, 50));

                    userCoeffs.delta_AbsolutePressureSensor = BitConverter.ToSingle(massive, 54);
                    break;
                #endregion

                #region Chem
                case LabType.chem:                 
                    userCoeffs.k_pHSensor = BitConverter.ToSingle(massive, 6);
                    userCoeffs.delta_pHSensor = BitConverter.ToSingle(massive, 10);
                    //userCoeffs.step_pHSensor_inPH = (byte)Math.Truncate(BitConverter.ToSingle(massive, 14));

                    userCoeffs.k_TempSensor = BitConverter.ToSingle(massive, 18);
                    userCoeffs.delta_TempSensor = BitConverter.ToSingle(massive, 22);
                    userCoeffs.step_TempSensor = (byte)Math.Truncate(BitConverter.ToSingle(massive, 26));

                    userCoeffs.k1_ConductivitySensor = BitConverter.ToSingle(massive, 30);
                    userCoeffs.delta1_ConductivitySensor = BitConverter.ToSingle(massive, 34);

                    userCoeffs.k2_ConductivitySensor = BitConverter.ToSingle(massive, 38);
                    userCoeffs.delta2_ConductivitySensor = BitConverter.ToSingle(massive, 42);

                    userCoeffs.k3_ConductivitySensor = BitConverter.ToSingle(massive, 46);
                    userCoeffs.delta3_ConductivitySensor = BitConverter.ToSingle(massive, 50);

                    //userCoeffs.step_ConductivitySensor = (byte)Math.Truncate(BitConverter.ToSingle(massive, 54));
                    break;
                #endregion

                case LabType.eco:
                    break;

                #region BIO
                case LabType.bio:                 
                    userCoeffs.k_pHSensor = BitConverter.ToSingle(massive, 6);
                    userCoeffs.delta_pHSensor = BitConverter.ToSingle(massive, 10);
                    //userCoeffs.step_pHSensor_inPH = (byte)Math.Truncate(BitConverter.ToSingle(massive, 14));

                    userCoeffs.k_TempSensor = BitConverter.ToSingle(massive, 18);
                    userCoeffs.delta_TempSensor = BitConverter.ToSingle(massive, 22);
                    userCoeffs.step_TempSensor = (byte)Math.Truncate(BitConverter.ToSingle(massive, 26));

                    userCoeffs.delta_TempOutsideSensor = BitConverter.ToSingle(massive, 30);
                    userCoeffs.delta_HumiditySensor = BitConverter.ToSingle(massive, 34);
                    userCoeffs.delta_LightSensor = BitConverter.ToSingle(massive, 38);
                    break;
                    #endregion
            }
            return userCoeffs;
        }

        /// <summary>
        /// чтение данных
        /// </summary>
        /// <param name="massive"></param>
        /// <param name="factoryCoeffs"></param>
        /// <param name="userSavedCoeffs"></param>
        /// <param name="userNewCoeffs"></param>
        /// <param name="pHSensor_mode"></param>
        /// <param name="conductScale"></param>
        /// <returns></returns>
        public Data[] Answer_Data_exchange(byte[] massive, FactoryCoeffs factoryCoeffs, UserCoeffs userSavedCoeffs, UserCoeffs userNewCoeffs, ConductScale conductScale)
        {
            Data[] fullData = new Data[2];
            #region Сырые данные
            DataBoard dataBoard = new DataBoard();

            var state = ByteToBits(massive[4]);
            dataBoard.Press_ok = state[3];
            dataBoard.Hum_ok = state[2];
            dataBoard.Light_ok = state[1];
            dataBoard.Accel_ok = state[0];

            dataBoard.ConductScale = (ConductScale)massive[5];

            dataBoard.TempADC = BitConverter.ToInt16(massive, 12) * 0.01F;

            dataBoard.Channel0 = BitConverter.ToSingle(massive, 16);
            dataBoard.Channel1 = BitConverter.ToSingle(massive, 20);
            dataBoard.Channel2 = BitConverter.ToSingle(massive, 24);
            dataBoard.Channel3 = BitConverter.ToSingle(massive, 28);

            dataBoard.AccelX = BitConverter.ToInt16(massive, 32);
            dataBoard.AccelY = BitConverter.ToInt16(massive, 34);
            dataBoard.AccelZ = BitConverter.ToInt16(massive, 36);
            dataBoard.AccelScale = (AccelScale)massive[38];

            dataBoard.Light = BitConverter.ToSingle(massive, 40);
            dataBoard.Humidity = BitConverter.ToUInt16(massive, 44) * 0.01F;

            dataBoard.Pressure = BitConverter.ToSingle(massive, 48);
            #endregion

            #region C учетом коэффициентов
            
            Data data = new Data();
            Data data_withFactoryCoef = new Data();

            #region Accelerometr пересчет в зависимости от диапазона (физика)
            if (dataBoard.Accel_ok)
            {
                switch (dataBoard.AccelScale)
                {
                    case AccelScale.g2:
                        data.AccelerometerXSensor = dataBoard.AccelX * _2g_coeff;
                        data.AccelerometerYSensor = dataBoard.AccelY * _2g_coeff;
                        data.AccelerometerZSensor = dataBoard.AccelZ * _2g_coeff;
                        break;

                    case AccelScale.g4:
                        data.AccelerometerXSensor = dataBoard.AccelX * _4g_coeff;
                        data.AccelerometerYSensor = dataBoard.AccelY * _4g_coeff;
                        data.AccelerometerZSensor = dataBoard.AccelZ * _4g_coeff;
                        break;

                    case AccelScale.g8:
                        data.AccelerometerXSensor = dataBoard.AccelX * _8g_coeff;
                        data.AccelerometerYSensor = dataBoard.AccelY * _8g_coeff;
                        data.AccelerometerZSensor = dataBoard.AccelZ * _8g_coeff;
                        break;

                    case AccelScale.g16:
                        data.AccelerometerXSensor = dataBoard.AccelX * _16g_coeff;
                        data.AccelerometerYSensor = dataBoard.AccelY * _16g_coeff;
                        data.AccelerometerZSensor = dataBoard.AccelZ * _16g_coeff;
                        break;
                }
            }
            #endregion

            #region датчик давления (физика)
            data_withFactoryCoef.AbsolutePressureSensor = dataBoard.Pressure * 0.1F + factoryCoeffs.delta_AbsolutePressureSensor; //перевод в кПа
            data.AbsolutePressureSensor = data_withFactoryCoef.AbsolutePressureSensor + userSavedCoeffs.delta_AbsolutePressureSensor;
            #endregion

            #region датчик температуры - 2 канал АЦП (физика, химияб биология)
            if (dataBoard.Channel2 < factoryCoeffs.pointT_Channel2)
            {
                data_withFactoryCoef.TempSensor = dataBoard.Channel2 * factoryCoeffs.k1_Channel2 + factoryCoeffs.delta1_Channel2;
            }
            else
            {
                data_withFactoryCoef.TempSensor = dataBoard.Channel2 * factoryCoeffs.k2_Channel2 + factoryCoeffs.delta2_Channel2;
            }
            switch (userSavedCoeffs.step_TempSensor)
            {
                case 1:
                    data.TempSensor = data_withFactoryCoef.TempSensor + userSavedCoeffs.delta_TempSensor;
                    break;
                case 2:
                    data.TempSensor = data_withFactoryCoef.TempSensor * userSavedCoeffs.k_TempSensor + userSavedCoeffs.delta_TempSensor;
                    break;
            }
            #endregion

            #region тесламетр - канал 3 (физика)
            data_withFactoryCoef.TeslametrSensor = dataBoard.Channel3 * factoryCoeffs.k1_Channel3 + factoryCoeffs.delta1_Channel3;
            switch (userSavedCoeffs.step_TeslametrSensor)
            {
                case 1:
                    data.TeslametrSensor = data_withFactoryCoef.TeslametrSensor + userSavedCoeffs.delta_TeslametrSensor;
                    break;
                case 2:
                    data.TeslametrSensor = data_withFactoryCoef.TeslametrSensor * userSavedCoeffs.k_TeslametrSensor + userSavedCoeffs.delta_TeslametrSensor;
                    break;
            }
            #endregion

            #region вольтметр - канал 0 (физика)
            data_withFactoryCoef.VoltmeterSensor = dataBoard.Channel0 * factoryCoeffs.k_Channel0 + factoryCoeffs.delta_Channel0;
            switch (userSavedCoeffs.step_VoltmeterSensor)
            {
                case 1:
                    data.VoltmeterSensor = data_withFactoryCoef.VoltmeterSensor + userSavedCoeffs.delta_VoltmeterSensor;
                    break;
                case 2:
                    data.VoltmeterSensor = data_withFactoryCoef.VoltmeterSensor * userSavedCoeffs.k_VoltmeterSensor + userSavedCoeffs.delta_VoltmeterSensor;
                    break;
            }
            #endregion

            #region амперметр - канал 1 (физика)
            data_withFactoryCoef.AmpermetrSensor = dataBoard.Channel1 * factoryCoeffs.k_Channel1 + factoryCoeffs.delta_Channel1;
            switch (userSavedCoeffs.step_AmpermetrSensor)
            {
                case 1:
                    data.AmpermetrSensor = data_withFactoryCoef.AmpermetrSensor + userSavedCoeffs.delta_AmpermetrSensor;
                    break;
                case 2:
                    data.AmpermetrSensor = data_withFactoryCoef.AmpermetrSensor * userSavedCoeffs.k_AmpermetrSensor + userSavedCoeffs.delta_AmpermetrSensor;
                    break;
            }
            #endregion

            #region датчик рН - 0 канал (химия)
            data_withFactoryCoef.PhSensor = dataBoard.Channel0 * 1000 * factoryCoeffs.k_Channel0 + factoryCoeffs.delta_Channel0;
            data.PhSensor = data_withFactoryCoef.PhSensor * userSavedCoeffs.k_pHSensor + userSavedCoeffs.delta_pHSensor;
            #endregion

            #region датчик электропроводимсоти - 3 канал (химия)
            data_withFactoryCoef.ElectricalConductivitySensor = dataBoard.Channel3 * factoryCoeffs.k1_Channel3 + factoryCoeffs.delta1_Channel3;
            switch (conductScale)
            {
                case ConductScale.k0:
                    break;
                case ConductScale.k1:
                    data.ElectricalConductivitySensor = data_withFactoryCoef.ElectricalConductivitySensor * userSavedCoeffs.k1_ConductivitySensor + userSavedCoeffs.delta1_ConductivitySensor;
                    break;
                case ConductScale.k10:
                    data.ElectricalConductivitySensor = data_withFactoryCoef.ElectricalConductivitySensor * userSavedCoeffs.k2_ConductivitySensor + userSavedCoeffs.delta2_ConductivitySensor;
                    break;
                case ConductScale.k100:
                    data.ElectricalConductivitySensor = data_withFactoryCoef.ElectricalConductivitySensor * userSavedCoeffs.k3_ConductivitySensor + userSavedCoeffs.delta3_ConductivitySensor;
                    break;
            }
            #endregion

            #region датчик влажности (биология)
            data_withFactoryCoef.HumiditySensor = dataBoard.Humidity + factoryCoeffs.delta_HumiditySensor;
            data.HumiditySensor = data_withFactoryCoef.HumiditySensor + userSavedCoeffs.delta_HumiditySensor;
            #endregion

            #region датчик освещенности (биология)
            data_withFactoryCoef.LightSensor = dataBoard.Light + factoryCoeffs.delta_LightSensor;
            data.LightSensor = data_withFactoryCoef.LightSensor + userSavedCoeffs.delta_LightSensor;
            #endregion
            

            #region датчик температуры окруж.среды (биология)
            data_withFactoryCoef.TempOutsideSensor = dataBoard.TempADC + factoryCoeffs.delta_ToutSensor;
            data.TempOutsideSensor = data_withFactoryCoef.TempOutsideSensor + userSavedCoeffs.delta_TempOutsideSensor;
            #endregion
            #endregion

            #region Данные для отображения в окне калибровки

            #region датчик температуры (физика, химия, биология)
            switch (userNewCoeffs.step_TempSensor)
            {
                case 1:
                    data.TempSensor_Calibr = data_withFactoryCoef.TempSensor + userNewCoeffs.delta_TempSensor;
                    break;
                case 2:
                    data.TempSensor_Calibr = data_withFactoryCoef.TempSensor * userNewCoeffs.k_TempSensor + userNewCoeffs.delta_TempSensor;
                    break;
            }
            #endregion

            #region Тесламетр (физика)
            switch (userNewCoeffs.step_TeslametrSensor)
            {
                case 1:
                    data.TeslametrSensor_Calibr = data_withFactoryCoef.TeslametrSensor + userNewCoeffs.delta_TeslametrSensor;
                    break;
                case 2:
                    data.TeslametrSensor_Calibr = data_withFactoryCoef.TeslametrSensor * userNewCoeffs.k_TeslametrSensor + userNewCoeffs.delta_TeslametrSensor;
                    break;
            }
            #endregion

            #region Вольтметр (физика)
            switch (userNewCoeffs.step_VoltmeterSensor)
            {
                case 1:
                    data.VoltmeterSensor_Calibr = data_withFactoryCoef.VoltmeterSensor + userNewCoeffs.delta_VoltmeterSensor;
                    break;
                case 2:
                    data.VoltmeterSensor_Calibr = data_withFactoryCoef.VoltmeterSensor * userNewCoeffs.k_VoltmeterSensor + userNewCoeffs.delta_VoltmeterSensor;
                    break;
            }
            #endregion

            #region Амперметр (физика)
            switch (userNewCoeffs.step_AmpermetrSensor)
            {
                case 1:
                    data.AmpermetrSensor_Calibr = data_withFactoryCoef.AmpermetrSensor + userNewCoeffs.delta_AmpermetrSensor;
                    break;
                case 2:
                    data.AmpermetrSensor_Calibr = data_withFactoryCoef.AmpermetrSensor * userNewCoeffs.k_AmpermetrSensor + userNewCoeffs.delta_AmpermetrSensor;
                    break;
            }
            #endregion

            #region Датчик давления (физика)
            data.AbsolutePressureSensor_Calibr = data_withFactoryCoef.AbsolutePressureSensor + userNewCoeffs.delta_AbsolutePressureSensor;
            #endregion

            #region pH (химия)
            data.PhSensor_Calibr = data.PhSensor * userNewCoeffs.k_pHSensor + userNewCoeffs.delta_pHSensor;
            #endregion

            #region датчик электропроводимсоти (химия)
            switch (conductScale)
            {
                case ConductScale.k0:
                    break;
                case ConductScale.k1:
                    data.ElectricalConductivitySensor_Calibr = data_withFactoryCoef.ElectricalConductivitySensor * userNewCoeffs.k1_ConductivitySensor + userNewCoeffs.delta1_ConductivitySensor;
                    break;
                case ConductScale.k10:
                    data.ElectricalConductivitySensor_Calibr = data_withFactoryCoef.ElectricalConductivitySensor * userNewCoeffs.k2_ConductivitySensor + userNewCoeffs.delta2_ConductivitySensor;
                    break;
                case ConductScale.k100:
                    data.ElectricalConductivitySensor_Calibr = data_withFactoryCoef.ElectricalConductivitySensor * userNewCoeffs.k3_ConductivitySensor + userNewCoeffs.delta3_ConductivitySensor;
                    break;
            }
            #endregion

            #region датчик влажности (биология)
            data.HumiditySensor_Calibr = data_withFactoryCoef.HumiditySensor + userNewCoeffs.delta_HumiditySensor;
            #endregion

            #region датчик освещенности (биология)
            data.LightSensor_Calibr = data_withFactoryCoef.LightSensor + userNewCoeffs.delta_LightSensor;
            #endregion

            #region датчик температуры наружн (биология)
            data.TempOutsideSensor_Calibr = data_withFactoryCoef.TempOutsideSensor + userNewCoeffs.delta_TempOutsideSensor;
            #endregion

            #endregion

            fullData[0] = data_withFactoryCoef;
            fullData[1] = data;

            return fullData;
        }
      
        /// <summary>
        /// чтение статуса текущего архива
        /// </summary>
        /// <returns></returns>
        public ArchiveSettings Answer_archive_Control_read(byte[] massive)
        {
            ArchiveSettings archiveSettingsFromDevice = new ArchiveSettings();
            archiveSettingsFromDevice.RecordPeriod = BitConverter.ToUInt32(massive, 4);
            archiveSettingsFromDevice.RecordNumber = massive[8];
            archiveSettingsFromDevice.ArchiveStatus = massive[9];
            archiveSettingsFromDevice.StartRecord_year_Int = 2000 + massive[11];
            archiveSettingsFromDevice.StartRecord_month = massive[12];
            archiveSettingsFromDevice.StartRecord_day = massive[13];
            archiveSettingsFromDevice.StartRecord_hour = massive[14];
            archiveSettingsFromDevice.StartRecord_min = massive[15];
            archiveSettingsFromDevice.StartRecord_sec = massive[16];

            return archiveSettingsFromDevice;
        }
        
        /// <summary>
        /// чтение серийного номера
        /// </summary>
        /// <param name="massive"></param>
        /// <returns></returns>
        public UInt32 Answer_proto_msgType_bootloader_get_FW_Cfg(byte[] massive)
        {
            return BitConverter.ToUInt32(massive, 4);
        }

        /// <summary>
        /// чтение архивных данных - вспомогательные
        /// </summary>
        /// <param name="massive"></param>
        /// <param name="l"></param>
        /// <returns></returns>
        public DataBoard ArchiveData(byte[] massive, int l)
        {
            DataBoard archiveData = new DataBoard();

            var stateArchive = ByteToBits(massive[6 + 64 * l]);
            archiveData.Press_ok = stateArchive[3];
            archiveData.Hum_ok = stateArchive[2];
            archiveData.Light_ok = stateArchive[1];
            archiveData.Accel_ok = stateArchive[0];

            archiveData.ConductScale = (ConductScale)massive[7 + 64 * l];

            archiveData.TempADC = BitConverter.ToInt16(massive, 14 + 64 * l) * 0.01F;

            archiveData.Channel0 = BitConverter.ToSingle(massive, 18 + 64 * l);
            archiveData.Channel1 = BitConverter.ToSingle(massive, 22 + 64 * l);
            archiveData.Channel2 = BitConverter.ToSingle(massive, 26 + 64 * l);
            archiveData.Channel3 = BitConverter.ToSingle(massive, 30 + 64 * l);

            archiveData.AccelX = BitConverter.ToInt16(massive, 34 + 64 * l);
            archiveData.AccelY = BitConverter.ToInt16(massive, 36 + 64 * l);
            archiveData.AccelZ = BitConverter.ToInt16(massive, 38 + 64 * l);
            archiveData.AccelScale = (AccelScale)massive[40 + 64 * l];

            archiveData.Light = BitConverter.ToSingle(massive, 42 + 64 * l);
            archiveData.Humidity = BitConverter.ToUInt16(massive, 46 + 64 * l) * 0.01F;

            archiveData.Pressure = BitConverter.ToSingle(massive, 50 + 64 * l);

            return archiveData;
        }

    }
}
