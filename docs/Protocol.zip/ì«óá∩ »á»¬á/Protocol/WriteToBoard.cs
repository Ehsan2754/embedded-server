﻿using HardwareLib.Classes;
using HardwareLib.ModbusCRC16;
using HardwareLib.Update;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using Windows.Devices.Bluetooth;
using Windows.Devices.Bluetooth.Advertisement;
using Windows.Devices.Bluetooth.GenericAttributeProfile;

namespace HardwareLib
{
    public class WriteToBoard
    {
        const byte unsupportMsg = 0xFF;
        const byte startByte = 0xAA;

        const byte data_exchange = 0x10;
        const byte get_HW_Config = 0x31;
        const byte get_UserData = 0x41;
        const byte set_UserData = 0x40;
        const byte proto_msgType_getInfo = 0x00;
        const byte archive_Control = 0x20;
        const byte getArchive = 0x21;
        const byte proto_msgType_bootloader_get_FW_Cfg = 0x83;

        #region CRC Modbus
        private static byte[] CalculateCrc16Modbus(byte[] bytes)
        {
            byte[] myArray = new byte[bytes.Length - 2];
            for (int i = 0; i < myArray.Length; i++)
            {
                myArray[i] = bytes[i];
            }
            CrcStdParams.StandartParameters.TryGetValue(CrcAlgorithms.Crc16Modbus, out Parameters crc_p);
            Crc crc = new Crc(crc_p);
            crc.Initialize();
            var crc_bytes = crc.ComputeHash(myArray);
            return crc_bytes;
        }

        private bool CheckAnswer(byte[] answerArray)
        {
            bool correct;
            var crc = CalculateCrc16Modbus(answerArray);
            correct = crc[0] == answerArray[answerArray.Length - 2] && crc[1] == answerArray[answerArray.Length - 1];
            return correct;
        }
        #endregion

        /// <summary>
        /// Запрос режима работы (загрузчик, основная), состояние конфигов
        /// </summary>
        /// <returns></returns>
        public byte[] Proto_msgType_getInfo()
        {
            byte[] writeMessage = new byte[6];
            writeMessage[0] = startByte;

            writeMessage[1] = BitConverter.GetBytes(writeMessage.Length)[0];
            writeMessage[2] = BitConverter.GetBytes(writeMessage.Length)[1];

            writeMessage[3] = proto_msgType_getInfo;

            var crc = CalculateCrc16Modbus(writeMessage);
            writeMessage[4] = crc[0];
            writeMessage[5] = crc[1];

            return writeMessage;
        }

        /// <summary>
        /// чтение данных
        /// </summary>
        /// <returns></returns>
        public byte[] DataExchange_Read()
        {
            byte[] writeMessage = new byte[6];
            writeMessage[0] = startByte;
            writeMessage[1] = BitConverter.GetBytes(writeMessage.Length)[0];
            writeMessage[2] = BitConverter.GetBytes(writeMessage.Length)[1];
            writeMessage[3] = data_exchange;

            var crc = CalculateCrc16Modbus(writeMessage);
            writeMessage[4] = crc[0];
            writeMessage[5] = crc[1];

            return writeMessage;
        }

        /// <summary>
        /// Изменение шкалы, команда чтения данных с платы с параметрами управления
        /// </summary>
        /// <returns></returns>
        public byte[] DataExchange_WriteScales(byte accelScale, byte conductScale)
        {
            byte[] writeMessage = new byte[8];
            writeMessage[0] = startByte;
            writeMessage[1] = BitConverter.GetBytes(writeMessage.Length)[0];
            writeMessage[2] = BitConverter.GetBytes(writeMessage.Length)[1];
            writeMessage[3] = data_exchange;

            writeMessage[4] = accelScale;
            writeMessage[5] = conductScale;

            var crc = CalculateCrc16Modbus(writeMessage);
            writeMessage[6] = crc[0];
            writeMessage[7] = crc[1];

            return writeMessage;
        }

        /// <summary>
        /// Чтение заводских настроек
        /// </summary>
        /// <returns></returns>
        public byte[] Get_HW_Config()
        {
            byte[] writeMessage = new byte[6];
            writeMessage[0] = startByte;
            writeMessage[1] = BitConverter.GetBytes(writeMessage.Length)[0];
            writeMessage[2] = BitConverter.GetBytes(writeMessage.Length)[1];
            writeMessage[3] = get_HW_Config;

            var crc = CalculateCrc16Modbus(writeMessage);
            writeMessage[4] = crc[0];
            writeMessage[5] = crc[1];

            return writeMessage;
        }

        /// <summary>
        /// чтение пользовательских настроек
        /// </summary>
        /// <returns></returns>
        public byte[] Proto_msgType_get_UserData(byte DataOffset, byte DataSize)
        {
            byte[] writeMessage = new byte[8];
            writeMessage[0] = startByte;
            writeMessage[1] = BitConverter.GetBytes(writeMessage.Length)[0];
            writeMessage[2] = BitConverter.GetBytes(writeMessage.Length)[1];
            writeMessage[3] = get_UserData;

            writeMessage[4] = DataOffset;
            writeMessage[5] = DataSize;


            var crc = CalculateCrc16Modbus(writeMessage);
            writeMessage[6] = crc[0];
            writeMessage[7] = crc[1];

            return writeMessage;
        }

        /// <summary>
        /// запись пользовательских настроек - всех разом по проводам используется
        /// </summary>
        /// <returns></returns>
        public byte[] Proto_msgType_set_UserData(LabType labType, UserCoeffs userCoeff)
        {
            byte[] writeMessage = null;

            switch (labType)
            {
                #region PHYS
                case LabType.phys:
                    writeMessage = new byte[61];
                    writeMessage[0] = startByte;
                    writeMessage[1] = BitConverter.GetBytes(writeMessage.Length)[0];
                    writeMessage[2] = BitConverter.GetBytes(writeMessage.Length)[1];
                    writeMessage[3] = set_UserData;
                    writeMessage[4] = 0; //offset
                    writeMessage[5] = 52; 
                    writeMessage[6] = 1;

                    //температура
                    var kBytes_TempSensor_Phys = BitConverter.GetBytes(userCoeff.k_TempSensor);
                    writeMessage[7] = kBytes_TempSensor_Phys[0];
                    writeMessage[8] = kBytes_TempSensor_Phys[1];
                    writeMessage[9] = kBytes_TempSensor_Phys[2];
                    writeMessage[10] = kBytes_TempSensor_Phys[3];

                    var deltaBytes_TempSensor_Phys = BitConverter.GetBytes(userCoeff.delta_TempSensor);
                    writeMessage[11] = deltaBytes_TempSensor_Phys[0];
                    writeMessage[12] = deltaBytes_TempSensor_Phys[1];
                    writeMessage[13] = deltaBytes_TempSensor_Phys[2];
                    writeMessage[14] = deltaBytes_TempSensor_Phys[3];

                    var stepBytes_TempSensor_Phys = BitConverter.GetBytes((float)userCoeff.step_TempSensor);
                    writeMessage[15] = stepBytes_TempSensor_Phys[0];
                    writeMessage[16] = stepBytes_TempSensor_Phys[1];
                    writeMessage[17] = stepBytes_TempSensor_Phys[2];
                    writeMessage[18] = stepBytes_TempSensor_Phys[3];

                    //тесламетр
                    var kBytes_TeslametrSensor_Phys = BitConverter.GetBytes(userCoeff.k_TeslametrSensor);
                    writeMessage[19] = kBytes_TeslametrSensor_Phys[0];
                    writeMessage[20] = kBytes_TeslametrSensor_Phys[1];
                    writeMessage[21] = kBytes_TeslametrSensor_Phys[2];
                    writeMessage[22] = kBytes_TeslametrSensor_Phys[3];

                    var deltaBytes_TeslametrSensor_Phys = BitConverter.GetBytes(userCoeff.delta_TeslametrSensor);
                    writeMessage[23] = deltaBytes_TeslametrSensor_Phys[0];
                    writeMessage[24] = deltaBytes_TeslametrSensor_Phys[1];
                    writeMessage[25] = deltaBytes_TeslametrSensor_Phys[2];
                    writeMessage[26] = deltaBytes_TeslametrSensor_Phys[3];

                    var stepBytes_TeslametrSensor_Phys = BitConverter.GetBytes((float)userCoeff.step_TeslametrSensor);
                    writeMessage[27] = stepBytes_TeslametrSensor_Phys[0];
                    writeMessage[28] = stepBytes_TeslametrSensor_Phys[1];
                    writeMessage[29] = stepBytes_TeslametrSensor_Phys[2];
                    writeMessage[30] = stepBytes_TeslametrSensor_Phys[3];

                    //вольтметр
                    var kBytes_VoltmeterSensor_Phys = BitConverter.GetBytes(userCoeff.k_VoltmeterSensor);
                    writeMessage[31] = kBytes_VoltmeterSensor_Phys[0];
                    writeMessage[32] = kBytes_VoltmeterSensor_Phys[1];
                    writeMessage[33] = kBytes_VoltmeterSensor_Phys[2];
                    writeMessage[34] = kBytes_VoltmeterSensor_Phys[3];

                    var deltaBytes_VoltmeterSensor_Phys = BitConverter.GetBytes(userCoeff.delta_VoltmeterSensor);
                    writeMessage[35] = deltaBytes_VoltmeterSensor_Phys[0];
                    writeMessage[36] = deltaBytes_VoltmeterSensor_Phys[1];
                    writeMessage[37] = deltaBytes_VoltmeterSensor_Phys[2];
                    writeMessage[38] = deltaBytes_VoltmeterSensor_Phys[3];

                    var stepBytes_VoltmeterSensor_Phys = BitConverter.GetBytes((float)userCoeff.step_VoltmeterSensor);
                    writeMessage[39] = stepBytes_VoltmeterSensor_Phys[0];
                    writeMessage[40] = stepBytes_VoltmeterSensor_Phys[1];
                    writeMessage[41] = stepBytes_VoltmeterSensor_Phys[2];
                    writeMessage[42] = stepBytes_VoltmeterSensor_Phys[3];

                    //амперметр
                    var kBytes_AmpermetrSensor_Phys = BitConverter.GetBytes(userCoeff.k_AmpermetrSensor);
                    writeMessage[43] = kBytes_AmpermetrSensor_Phys[0];
                    writeMessage[44] = kBytes_AmpermetrSensor_Phys[1];
                    writeMessage[45] = kBytes_AmpermetrSensor_Phys[2];
                    writeMessage[46] = kBytes_AmpermetrSensor_Phys[3];

                    var deltaBytes_AmpermetrSensor_Phys = BitConverter.GetBytes(userCoeff.delta_AmpermetrSensor);
                    writeMessage[47] = deltaBytes_AmpermetrSensor_Phys[0];
                    writeMessage[48] = deltaBytes_AmpermetrSensor_Phys[1];
                    writeMessage[49] = deltaBytes_AmpermetrSensor_Phys[2];
                    writeMessage[50] = deltaBytes_AmpermetrSensor_Phys[3];

                    var stepBytes_AmpermetrSensor_Phys = BitConverter.GetBytes((float)userCoeff.step_AmpermetrSensor);
                    writeMessage[51] = stepBytes_AmpermetrSensor_Phys[0];
                    writeMessage[52] = stepBytes_AmpermetrSensor_Phys[1];
                    writeMessage[53] = stepBytes_AmpermetrSensor_Phys[2];
                    writeMessage[54] = stepBytes_AmpermetrSensor_Phys[3];

                    //давление
                    var deltaBytes_AbsPressureSensor = BitConverter.GetBytes(userCoeff.delta_AbsolutePressureSensor);
                    writeMessage[55] = deltaBytes_AbsPressureSensor[0];
                    writeMessage[56] = deltaBytes_AbsPressureSensor[1];
                    writeMessage[57] = deltaBytes_AbsPressureSensor[2];
                    writeMessage[58] = deltaBytes_AbsPressureSensor[3];

                    var crc = CalculateCrc16Modbus(writeMessage);
                    writeMessage[59] = crc[0];
                    writeMessage[60] = crc[1];
                    break;
                #endregion

                #region CHEM
                case LabType.chem:
                    writeMessage = new byte[61];
                    writeMessage[0] = startByte;
                    writeMessage[1] = BitConverter.GetBytes(writeMessage.Length)[0];
                    writeMessage[2] = BitConverter.GetBytes(writeMessage.Length)[1];
                    writeMessage[3] = set_UserData;
                    writeMessage[4] = 0; //offset
                    writeMessage[5] = 52; //user calibr data len
                    writeMessage[6] = 1;

                    //pH
                    var kBytes_pHSensor_chem = BitConverter.GetBytes(userCoeff.k_pHSensor);
                    writeMessage[7] = kBytes_pHSensor_chem[0];
                    writeMessage[8] = kBytes_pHSensor_chem[1];
                    writeMessage[9] = kBytes_pHSensor_chem[2];
                    writeMessage[10] = kBytes_pHSensor_chem[3];

                    var deltaBytes_pHSensor_chem = BitConverter.GetBytes(userCoeff.delta_pHSensor);
                    writeMessage[11] = deltaBytes_pHSensor_chem[0];
                    writeMessage[12] = deltaBytes_pHSensor_chem[1];
                    writeMessage[13] = deltaBytes_pHSensor_chem[2];
                    writeMessage[14] = deltaBytes_pHSensor_chem[3];

                    var stepBytes_pHSensor_chem = BitConverter.GetBytes((float)userCoeff.step_pHSensor);
                    writeMessage[15] = stepBytes_pHSensor_chem[0];
                    writeMessage[16] = stepBytes_pHSensor_chem[1];
                    writeMessage[17] = stepBytes_pHSensor_chem[2];
                    writeMessage[18] = stepBytes_pHSensor_chem[3];

                    //температура
                    var kBytes_TempSensor_chem = BitConverter.GetBytes(userCoeff.k_TempSensor);
                    writeMessage[19] = kBytes_TempSensor_chem[0];
                    writeMessage[20] = kBytes_TempSensor_chem[1];
                    writeMessage[21] = kBytes_TempSensor_chem[2];
                    writeMessage[22] = kBytes_TempSensor_chem[3];

                    var deltaBytes_TempSensor_chem = BitConverter.GetBytes(userCoeff.delta_TempSensor);
                    writeMessage[23] = deltaBytes_TempSensor_chem[0];
                    writeMessage[24] = deltaBytes_TempSensor_chem[1];
                    writeMessage[25] = deltaBytes_TempSensor_chem[2];
                    writeMessage[26] = deltaBytes_TempSensor_chem[3];

                    var stepBytes_TempSensor_chem = BitConverter.GetBytes((float)userCoeff.step_TempSensor);
                    writeMessage[27] = stepBytes_TempSensor_chem[0];
                    writeMessage[28] = stepBytes_TempSensor_chem[1];
                    writeMessage[29] = stepBytes_TempSensor_chem[2];
                    writeMessage[30] = stepBytes_TempSensor_chem[3];

                    //электропроводимость
                    var kBytes1_ConductivitySensor_chem = BitConverter.GetBytes(userCoeff.k1_ConductivitySensor);
                    writeMessage[31] = kBytes1_ConductivitySensor_chem[0];
                    writeMessage[32] = kBytes1_ConductivitySensor_chem[1];
                    writeMessage[33] = kBytes1_ConductivitySensor_chem[2];
                    writeMessage[34] = kBytes1_ConductivitySensor_chem[3];

                    var deltaBytes1_ConductivitySensor_chem = BitConverter.GetBytes(userCoeff.delta1_ConductivitySensor);
                    writeMessage[35] = deltaBytes1_ConductivitySensor_chem[0];
                    writeMessage[36] = deltaBytes1_ConductivitySensor_chem[1];
                    writeMessage[37] = deltaBytes1_ConductivitySensor_chem[2];
                    writeMessage[38] = deltaBytes1_ConductivitySensor_chem[3];

                    var kBytes2_ConductivitySensor_chem = BitConverter.GetBytes(userCoeff.k1_ConductivitySensor);
                    writeMessage[39] = kBytes2_ConductivitySensor_chem[0];
                    writeMessage[40] = kBytes2_ConductivitySensor_chem[1];
                    writeMessage[41] = kBytes2_ConductivitySensor_chem[2];
                    writeMessage[42] = kBytes2_ConductivitySensor_chem[3];

                    var deltaBytes2_ConductivitySensor_chem = BitConverter.GetBytes(userCoeff.delta1_ConductivitySensor);
                    writeMessage[43] = deltaBytes2_ConductivitySensor_chem[0];
                    writeMessage[44] = deltaBytes2_ConductivitySensor_chem[1];
                    writeMessage[45] = deltaBytes2_ConductivitySensor_chem[2];
                    writeMessage[46] = deltaBytes2_ConductivitySensor_chem[3];

                    var kBytes3_ConductivitySensor_chem = BitConverter.GetBytes(userCoeff.k1_ConductivitySensor);
                    writeMessage[47] = kBytes3_ConductivitySensor_chem[0];
                    writeMessage[48] = kBytes3_ConductivitySensor_chem[1];
                    writeMessage[49] = kBytes3_ConductivitySensor_chem[2];
                    writeMessage[50] = kBytes3_ConductivitySensor_chem[3];

                    var deltaBytes3_ConductivitySensor_chem = BitConverter.GetBytes(userCoeff.delta1_ConductivitySensor);
                    writeMessage[51] = deltaBytes3_ConductivitySensor_chem[0];
                    writeMessage[52] = deltaBytes3_ConductivitySensor_chem[1];
                    writeMessage[53] = deltaBytes3_ConductivitySensor_chem[2];
                    writeMessage[54] = deltaBytes3_ConductivitySensor_chem[3];
                   
                    var stepBytes_ConductivitySensor_chem = BitConverter.GetBytes((float)userCoeff.step_ConductivitySensor);
                    writeMessage[55] = stepBytes_ConductivitySensor_chem[0];
                    writeMessage[56] = stepBytes_ConductivitySensor_chem[1];
                    writeMessage[57] = stepBytes_ConductivitySensor_chem[2];
                    writeMessage[58] = stepBytes_ConductivitySensor_chem[3];

                    var crcChem = CalculateCrc16Modbus(writeMessage);
                    writeMessage[59] = crcChem[0];
                    writeMessage[60] = crcChem[1];
                    break;
                #endregion

                case LabType.eco:
                    break;

                #region BIO
                case LabType.bio:
                    writeMessage = new byte[45];
                    writeMessage[0] = startByte;
                    writeMessage[1] = BitConverter.GetBytes(writeMessage.Length)[0];
                    writeMessage[2] = BitConverter.GetBytes(writeMessage.Length)[1];
                    writeMessage[3] = set_UserData;
                    writeMessage[4] = 0; //offset
                    writeMessage[5] = 36; //user calibr data len
                    writeMessage[6] = 1;

                    //ph
                    var kBytes_pHSensor_bio = BitConverter.GetBytes(userCoeff.k_pHSensor);
                    writeMessage[7] = kBytes_pHSensor_bio[0];
                    writeMessage[8] = kBytes_pHSensor_bio[1];
                    writeMessage[9] = kBytes_pHSensor_bio[2];
                    writeMessage[10] = kBytes_pHSensor_bio[3];

                    var deltaBytes_pHSensor_bio = BitConverter.GetBytes(userCoeff.delta_pHSensor);
                    writeMessage[11] = deltaBytes_pHSensor_bio[0];
                    writeMessage[12] = deltaBytes_pHSensor_bio[1];
                    writeMessage[13] = deltaBytes_pHSensor_bio[2];
                    writeMessage[14] = deltaBytes_pHSensor_bio[3];

                    var stepBytes_pHSensor_bio = BitConverter.GetBytes((float)userCoeff.step_pHSensor);
                    writeMessage[15] = stepBytes_pHSensor_bio[0];
                    writeMessage[16] = stepBytes_pHSensor_bio[1];
                    writeMessage[17] = stepBytes_pHSensor_bio[2];
                    writeMessage[18] = stepBytes_pHSensor_bio[3];

                    //температура
                    var kBytes_TempSensor_bio = BitConverter.GetBytes(userCoeff.k_TempSensor);
                    writeMessage[19] = kBytes_TempSensor_bio[0];
                    writeMessage[20] = kBytes_TempSensor_bio[1];
                    writeMessage[21] = kBytes_TempSensor_bio[2];
                    writeMessage[22] = kBytes_TempSensor_bio[3];

                    var deltaBytes_TempSensor_bio = BitConverter.GetBytes(userCoeff.delta_TempSensor);
                    writeMessage[23] = deltaBytes_TempSensor_bio[0];
                    writeMessage[24] = deltaBytes_TempSensor_bio[1];
                    writeMessage[25] = deltaBytes_TempSensor_bio[2];
                    writeMessage[26] = deltaBytes_TempSensor_bio[3];

                    var stepBytes_TempSensor_bio = BitConverter.GetBytes((float)userCoeff.step_TempSensor);
                    writeMessage[27] = stepBytes_TempSensor_bio[0];
                    writeMessage[28] = stepBytes_TempSensor_bio[1];
                    writeMessage[29] = stepBytes_TempSensor_bio[2];
                    writeMessage[30] = stepBytes_TempSensor_bio[3];

                    //Tout
                    var deltaBytes_ToutSensor_bio = BitConverter.GetBytes(userCoeff.delta_TempOutsideSensor);
                    writeMessage[31] = deltaBytes_ToutSensor_bio[0];
                    writeMessage[32] = deltaBytes_ToutSensor_bio[1];
                    writeMessage[33] = deltaBytes_ToutSensor_bio[2];
                    writeMessage[34] = deltaBytes_ToutSensor_bio[3];

                    var deltaBytes_HumiditySensor_bio = BitConverter.GetBytes(userCoeff.delta_HumiditySensor);
                    writeMessage[35] = deltaBytes_HumiditySensor_bio[0];
                    writeMessage[36] = deltaBytes_HumiditySensor_bio[1];
                    writeMessage[37] = deltaBytes_HumiditySensor_bio[2];
                    writeMessage[38] = deltaBytes_HumiditySensor_bio[3];

                    var deltaBytes_LightSensor_bio = BitConverter.GetBytes(userCoeff.delta_LightSensor);
                    writeMessage[39] = deltaBytes_LightSensor_bio[0];
                    writeMessage[40] = deltaBytes_LightSensor_bio[1];
                    writeMessage[41] = deltaBytes_LightSensor_bio[2];
                    writeMessage[42] = deltaBytes_LightSensor_bio[3];

                    var crcBio = CalculateCrc16Modbus(writeMessage);
                    writeMessage[43] = crcBio[0];
                    writeMessage[44] = crcBio[1];
                    break;
                    #endregion
            }
            return writeMessage;
        }

        /// <summary>
        /// запрос информации текущего архива
        /// </summary>
        /// <returns></returns>
        public byte[] ArchiveControl_Info()
        {
            byte[] writeMessage = new byte[6];
            writeMessage[0] = startByte;
            writeMessage[1] = BitConverter.GetBytes(writeMessage.Length)[0];
            writeMessage[2] = BitConverter.GetBytes(writeMessage.Length)[1];
            writeMessage[3] = archive_Control;

            var crc = CalculateCrc16Modbus(writeMessage);
            writeMessage[4] = crc[0];
            writeMessage[5] = crc[1];

            return writeMessage;
        }

        /// <summary>
        /// запуск режима архива
        /// </summary>
        /// <param name="archive"></param>
        /// <returns></returns>
        public byte[] ArchiveControl_Start(ArchiveSettings archive)
        {
            byte[] writeMessage = new byte[19];
            writeMessage[0] = startByte;
            writeMessage[1] = BitConverter.GetBytes(writeMessage.Length)[0];
            writeMessage[2] = BitConverter.GetBytes(writeMessage.Length)[1];
            writeMessage[3] = archive_Control;


            writeMessage[4] = BitConverter.GetBytes(archive.RecordPeriod)[0];
            writeMessage[5] = BitConverter.GetBytes(archive.RecordPeriod)[1];
            writeMessage[6] = BitConverter.GetBytes(archive.RecordPeriod)[2];
            writeMessage[7] = BitConverter.GetBytes(archive.RecordPeriod)[3];
            writeMessage[8] = archive.RecordNumber;
            writeMessage[11] = archive.StartRecord_year;
            writeMessage[12] = archive.StartRecord_month;
            writeMessage[13] = archive.StartRecord_day;
            writeMessage[14] = archive.StartRecord_hour;
            writeMessage[15] = archive.StartRecord_min;
            writeMessage[16] = archive.StartRecord_sec;

            var crc = CalculateCrc16Modbus(writeMessage);
            writeMessage[17] = crc[0];
            writeMessage[18] = crc[1];

            return writeMessage;
        }

        /// <summary>
        /// чтение архива
        /// </summary>
        /// <param name="startAddr"></param>
        /// <param name="recordQtt"></param>
        /// <returns></returns>
        public byte[] Archive_Get(byte startAddr, byte recordQtt)
        {
            byte[] writeMessage = new byte[8];
            writeMessage[0] = startByte;
            writeMessage[1] = BitConverter.GetBytes(writeMessage.Length)[0];
            writeMessage[2] = BitConverter.GetBytes(writeMessage.Length)[1];
            writeMessage[3] = getArchive;

            writeMessage[4] = startAddr;
            writeMessage[5] = recordQtt;

            var crc = CalculateCrc16Modbus(writeMessage);
            writeMessage[6] = crc[0];
            writeMessage[7] = crc[1];

            return writeMessage;
        }

        /// <summary>
        /// чтение конфигурации программного обеспечения
        /// </summary>
        /// <returns></returns>
        public byte[] Proto_msgType_bootloader_get_FW_Cfg()
        {
            byte[] writeMessage = new byte[6];
            writeMessage[0] = startByte;
            writeMessage[1] = BitConverter.GetBytes(writeMessage.Length)[0];
            writeMessage[2] = BitConverter.GetBytes(writeMessage.Length)[1];
            writeMessage[3] = proto_msgType_bootloader_get_FW_Cfg;

            var crc = CalculateCrc16Modbus(writeMessage);
            writeMessage[4] = crc[0];
            writeMessage[5] = crc[1];

            return writeMessage;
        }
    }
}
